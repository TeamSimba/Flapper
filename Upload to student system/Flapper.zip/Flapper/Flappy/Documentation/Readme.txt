﻿Колеги,
документа е качен в Гоогле ДОКС, с идеята да се редкатира от всички.
линк към документа:
https://docs.google.com/document/d/16_Cjel0RV_Q0X5gHLyzr6Png1Z61v2cmgm801wmNPRQ/edit?usp=sharing

presentation link:
https://docs.google.com/presentation/d/1yaTFEHwAvpTaUAEbS8dCrDynOFI0ix3dGQKfLZFWnXU/edit?usp=sharing